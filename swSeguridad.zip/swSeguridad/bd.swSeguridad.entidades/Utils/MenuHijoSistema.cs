﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swseguridad.entidades.Utils
{
   public class MenuHijoSistema
    {
        public string AdmeAplicacion { get; set; }
        public string AdmeSistema { get; set; }
        public string Usuario { get; set; }
    }
}
