﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swseguridad.entidades.Enumeradores
{
    public enum Aplicacion
    {
        SwSeguridad
    } 
}
