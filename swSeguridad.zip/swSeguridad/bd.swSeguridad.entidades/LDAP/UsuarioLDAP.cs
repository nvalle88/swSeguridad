﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swseguridad.entidades.LDAP
{
    public class UsuarioLDAP
    {
        public string DisplayName { get; set; }
        public string Username { get; set; }
    }
}
