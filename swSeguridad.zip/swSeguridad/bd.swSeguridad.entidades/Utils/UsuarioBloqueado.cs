﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swseguridad.entidades.Utils
{
   public class UsuarioBloqueado
    {
        public bool EstaBloqueado { get; set; }
    }
}
