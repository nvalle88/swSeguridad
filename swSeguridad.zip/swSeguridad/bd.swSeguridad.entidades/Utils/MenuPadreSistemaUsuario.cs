﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swseguridad.entidades.Utils
{
   public class MenuPadreSistemaUsuario
    {
        public string Usuario { get; set; }
        public string Sistema { get; set; }
    }
}
