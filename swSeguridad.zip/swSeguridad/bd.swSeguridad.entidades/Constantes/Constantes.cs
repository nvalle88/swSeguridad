﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swseguridad.entidades.Constantes
{
  public static class Constantes
    {
      public static  string Referencia= "REFERENCE";
      public static string UsuarioInterno = "INTERNO";
    }
}
