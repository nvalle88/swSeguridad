﻿using bd.swseguridad.entidades.Negocio;

namespace bd.swseguridad.entidades.ObjectTranfer
{
    public class ModuloAplicacion
    {
        public string Path { get; set; }
        public string NombreAplicacion { get; set; }
    }
}
